import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import LoginModal from "./components/LoginModal";
import TabInicio from "./components/TabInicio";
import TabInstituicoes from "./components/TabInstituicoes";
import TabEditais from "./components/TabEditais";
import TabOrientacao from "./components/TabOrientacao";

import { CURITIBA_INSTITUTIONS, CURITIBA_DEADLINES, CAREER_AREAS } from "./data";
import { Institution, EditalDeadline, CareerArea, ChatMessage, UserSession } from "./types";
import { ShieldCheck, Info, X, ExternalLink, RefreshCw, Send, CheckCircle2 } from "lucide-react";

export default function App() {
  // Page routing
  const [activeTab, setActiveTab] = useState<"inicio" | "instituicoes" | "editais" | "orientacao">("inicio");
  
  // Accessibility
  const [highContrast, setHighContrast] = useState(false);
  const [fontSizeMultiplier, setFontSizeMultiplier] = useState(1.0);

  // Authentication State with LocalStorage memory persistence
  const [userSession, setUserSession] = useState<UserSession>(() => {
    try {
      const saved = localStorage.getItem("guiaestudantil_session");
      if (saved) {
        return { isAuthenticated: true, user: JSON.parse(saved) };
      }
    } catch (e) {
      console.error("Erro ao resgatar session local", e);
    }
    return { isAuthenticated: false, user: null };
  });

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Modal inspection of Editais
  const [activeDeadlineModal, setActiveDeadlineModal] = useState<EditalDeadline | null>(null);
  
  // Mock intelligent application simulation state inside the detailed model
  const [submittingIsencao, setSubmittingIsencao] = useState(false);
  const [isencaoSuccess, setIsencaoSuccess] = useState(false);

  // Load chat initial greeting
  const initialChatHistory: ChatMessage[] = [
    {
      id: "greet-1",
      sender: "assistant",
      text: "Olá! Seja bem-vindo ao portal unificado GuiaEstudantil de Curitiba e Região.\nSua busca por editais, vestibulares públicos, isenção de taxas e escolhas de carreira termina aqui.\n\nComo posso ajudar você hoje em sua jornada de estudos?",
      timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
    },
  ];

  // Callback to communicate server-side Gemini API
  const handleChatSendMessage = async (text: string): Promise<string> => {
    try {
      // Reconstruct simple history representing last 4 messages to optimize token budget
      const response = await fetch("/api/assistant", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: text,
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Erro de rede no servidor");
      }

      const data = await response.json();
      return data.text;
    } catch (error: any) {
      console.error("Erro na comunicação com o assistente:", error);
      throw error;
    }
  };

  const handleLoginSuccess = (user: { email: string; fullName: string; originSchool?: string }) => {
    const sessionData = {
      email: user.email,
      fullName: user.fullName,
      originSchool: user.originSchool || "Geral",
    };
    try {
      localStorage.setItem("guiaestudantil_session", JSON.stringify(sessionData));
    } catch (e) {
      console.error(e);
    }
    setUserSession({
      isAuthenticated: true,
      user: sessionData,
    });
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem("guiaestudantil_session");
    } catch (e) {
      console.error(e);
    }
    setUserSession({
      isAuthenticated: false,
      user: null,
    });
  };

  // Accessibility controllers
  const toggleContrast = () => {
    setHighContrast(!highContrast);
  };

  const adjustFontSize = (direction: "up" | "down" | "reset") => {
    if (direction === "up") {
      setFontSizeMultiplier((prev) => Math.min(prev + 0.1, 1.3));
    } else if (direction === "down") {
      setFontSizeMultiplier((prev) => Math.max(prev - 0.1, 0.9));
    } else {
      setFontSizeMultiplier(1.0);
    }
  };

  // Smart application simulation
  const handleSimulateIsencao = () => {
    setSubmittingIsencao(true);
    setTimeout(() => {
      setSubmittingIsencao(false);
      setIsencaoSuccess(true);
    }, 1500);
  };

  // Reset smart application state when closing modal
  const handleCloseDeadlineModal = () => {
    setActiveDeadlineModal(null);
    setIsencaoSuccess(false);
    setSubmittingIsencao(false);
  };

  return (
    <div className={`min-h-screen flex flex-col ${highContrast ? "high-contrast" : ""}`} style={{ fontSize: `${fontSizeMultiplier}rem` }}>
      {/* Upper Navigation Header */}
      <Header
        currentTab={activeTab}
        onTabChange={setActiveTab}
        userSession={userSession}
        onLogout={handleLogout}
        onOpenLogin={() => setIsLoginModalOpen(true)}
        highContrast={highContrast}
        onToggleContrast={toggleContrast}
        fontSizeMultiplier={fontSizeMultiplier}
        onAdjustFontSize={adjustFontSize}
      />

      {/* Main Body Layout */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 py-6 md:py-8">
        <div id="content-container" className="animate-fade-in">
          {activeTab === "inicio" && (
            <TabInicio
              deadlines={CURITIBA_DEADLINES}
              institutions={CURITIBA_INSTITUTIONS}
              onNavigateTab={setActiveTab}
              onOpenLogin={() => setIsLoginModalOpen(true)}
              isAuthenticated={userSession.isAuthenticated}
              onSelectDeadline={setActiveDeadlineModal}
            />
          )}

          {activeTab === "instituicoes" && (
            <TabInstituicoes institutions={CURITIBA_INSTITUTIONS} />
          )}

          {activeTab === "editais" && (
            <TabEditais
              deadlines={CURITIBA_DEADLINES}
              onSelectDeadline={setActiveDeadlineModal}
            />
          )}

          {activeTab === "orientacao" && (
            <TabOrientacao
              careerAreas={CAREER_AREAS}
              initialChatHistory={initialChatHistory}
              onSendMessage={handleChatSendMessage}
            />
          )}
        </div>
      </main>

      {/* Official Reassuring footer */}
      <Footer />

      {/* MODAL 1: Authenticação Unificada PR */}
      {isLoginModalOpen && (
        <LoginModal
          onClose={() => setIsLoginModalOpen(false)}
          onLoginSuccess={handleLoginSuccess}
          // Utilizing user mail reference in parameters
          userEmailFromMetadata="faculdaproject@gmail.com"
        />
      )}

      {/* MODAL 2: Rich Inspectors for Specific Deadlines */}
      {activeDeadlineModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl w-full max-w-lg overflow-hidden border border-slate-200 animate-scale-up" id="deadline-inspect-modal">
            {/* Header */}
            <div className="bg-[#002f6c] text-white px-5 py-4 flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <span className="text-[10px] inline-block uppercase font-bold tracking-wider bg-amber-400 text-slate-950 px-2.5 py-0.5 rounded">
                  {activeDeadlineModal.type}
                </span>
                <span className="text-xs text-slate-200 font-light hidden sm:inline-block">
                  • Edital {activeDeadlineModal.institutionId.toUpperCase()}
                </span>
              </div>
              <button
                onClick={handleCloseDeadlineModal}
                className="text-slate-300 hover:text-white transition duration-150 p-1 hover:bg-[#001d44] rounded"
              >
                <X size={18} />
              </button>
            </div>

            {/* Inspect Body */}
            <div className="p-5 space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 m-0">
                  {activeDeadlineModal.title}
                </h3>
                <p className="text-xs text-slate-400 font-light mt-0.5">
                  Instituição parceira: <span className="font-semibold text-slate-700">{activeDeadlineModal.institutionName}</span>
                </p>
              </div>

              {/* Deadline alert card */}
              <div className="flex items-center justify-between p-3 bg-blue-50 border border-blue-100 rounded-md">
                <span className="text-xs font-bold text-slate-700 block">Cronograma de Submissão:</span>
                <span className="text-xs font-bold text-[#002f6c] bg-white border border-blue-200 px-2 py-0.5 rounded font-mono">
                  {activeDeadlineModal.deadlineDate}
                </span>
              </div>

              <div className="space-y-3">
                <p className="text-xs text-slate-600 font-light leading-relaxed">
                  {activeDeadlineModal.description}
                </p>

                {activeDeadlineModal.requirements && (
                  <div className="p-3 bg-slate-50 rounded-md border border-slate-100 space-y-1.5">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Requisitos Mínimos Necessários
                    </span>
                    <p className="text-xs text-slate-700 font-light">
                      {activeDeadlineModal.requirements}
                    </p>
                  </div>
                )}
              </div>

              {/* INTEGRATED INTELLIGENT SOLICITATION FLOW */}
              {activeDeadlineModal.type === "Isenção de Taxa" && (
                <div className="mt-4 border-t border-slate-100 pt-4">
                  {userSession.isAuthenticated && userSession.user ? (
                    <div className="bg-emerald-50/50 border border-emerald-200 rounded-lg p-3.5 space-y-3">
                      <div className="flex items-start space-x-2.5">
                        <ShieldCheck className="text-emerald-600 shrink-0 mt-0.5" size={16} />
                        <div>
                          <span className="text-[11px] font-bold text-emerald-800 uppercase block">
                            Solicitação Integrada de Isenção PR
                          </span>
                          <p className="text-[10px] text-slate-600 leading-normal font-light">
                            Verificamos que você concluiu o Ensino Médio na instituição: <span className="font-semibold text-slate-800">"{userSession.user.originSchool}"</span>. Essa origem garante isenção automática perante o banco de dados da SEED-PR.
                          </p>
                        </div>
                      </div>

                      {isencaoSuccess ? (
                        <div className="bg-emerald-600 text-white p-2.5 rounded text-xs font-semibold flex items-center space-x-1.5 animate-fade-in">
                          <CheckCircle2 size={14} />
                          <span>Pedido integrado enviado com sucesso! Protocolo PR-2026-{Math.floor(Math.random() * 90000 + 10000)}</span>
                        </div>
                      ) : (
                        <button
                          onClick={handleSimulateIsencao}
                          disabled={submittingIsencao}
                          className="w-full py-1.5 bg-emerald-700 hover:bg-emerald-805 text-white rounded text-xs font-semibold uppercase tracking-wider transition flex items-center justify-center space-x-1.5"
                        >
                          {submittingIsencao ? (
                            <>
                              <RefreshCw size={12} className="animate-spin" />
                              <span>Validando junto ao SERE-PR...</span>
                            </>
                          ) : (
                            <span>Requisitar Isenção Automática Única</span>
                          )}
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="text-[10px] font-bold text-slate-500 uppercase block">Isenção Integrada</span>
                        <span className="text-[11px] text-slate-600 font-light block">Conecte sua conta de estudante PR para solicitar automaticamente.</span>
                      </div>
                      <button
                        onClick={() => {
                          handleCloseDeadlineModal();
                          setIsLoginModalOpen(true);
                        }}
                        className="px-2.5 py-1 bg-[#002f6c] text-white text-[10px] font-bold rounded uppercase tracking-wider"
                      >
                        Conectar
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Modal Footer Redirects */}
            <div className="bg-slate-50 border-t border-slate-100 p-3 flex justify-between items-center gap-2">
              <span className="text-[9px] text-slate-400 font-light">
                Verifique sempre o adendo oficial da instituição.
              </span>
              <div className="flex space-x-2">
                <button
                  onClick={handleCloseDeadlineModal}
                  className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded text-xs font-semibold cursor-pointer"
                >
                  Fechar Painel
                </button>
                <a
                  href={activeDeadlineModal.officialLink}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  className="px-3 py-1.5 bg-[#002f6c] hover:bg-[#001d44] text-white rounded text-xs font-bold flex items-center space-x-1 cursor-pointer"
                >
                  <span className="text-white">Acessar Edital Oficial</span>
                  <ExternalLink size={12} />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
