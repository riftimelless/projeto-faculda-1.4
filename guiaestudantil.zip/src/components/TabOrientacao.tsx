import React, { useState, useRef, useEffect, useMemo } from "react";
import { Send, Sparkles, MessageSquare, Briefcase, GraduationCap, Coins, ThumbsUp, Compass, ArrowRight, ShieldAlert, Binary, Stethoscope, Palette, TrendingUp, Map } from "lucide-react";
import { CareerArea, ChatMessage } from "../types";

// Dynamic map to translate string icons to Lucide components
const IconMap: { [key: string]: React.ComponentType<any> } = {
  Binary: Binary,
  Stethoscope: Stethoscope,
  Palette: Palette,
  TrendingUp: TrendingUp,
  Map: Map,
};

interface TabOrientacaoProps {
  careerAreas: CareerArea[];
  initialChatHistory: ChatMessage[];
  onSendMessage: (message: string) => Promise<string>;
}

export default function TabOrientacao({
  careerAreas,
  initialChatHistory,
  onSendMessage,
}: TabOrientacaoProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialChatHistory);
  const [inputValue, setInputValue] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [selectedCareer, setSelectedCareer] = useState<CareerArea | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Suggestion Chips
  const suggestionChips = [
    "Qual a diferença entre UFPR e UTFPR para engenharia?",
    "Que áreas de TI estão contratando em Curitiba?",
    "Quais instituições dão bolsas de estudo integrais?",
    "Como se preparar para a redação da PUCPR?",
  ];

  const handleSendText = async (text: string) => {
    if (!text.trim() || isSending) return;

    const userMsg: ChatMessage = {
      id: "usr-" + Date.now(),
      sender: "user",
      text: text,
      timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsSending(true);

    try {
      // Prompt backend Express server
      const assistantResponseText = await onSendMessage(text);

      const assistantMsg: ChatMessage = {
        id: "ast-" + Date.now(),
        sender: "assistant",
        text: assistantResponseText,
        timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (error) {
      console.error(error);
      const errorMsg: ChatMessage = {
        id: "err-" + Date.now(),
        sender: "assistant",
        text: "Houve um erro em nosso sistema de transmissão municipal. Verifique seus Secrets API no painel do AI Studio para garantir que a GEMINI_API_KEY está configurada corretamente.",
        timestamp: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsSending(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendText(inputValue);
  };

  // Quick career selection handler
  const triggerCareerAssistantQuestion = (careerName: string) => {
    handleSendText(`Me dê mais detalhes e perspectivas de carreira para a área de ${careerName} em Curitiba.`);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="orientacao-panel">
      {/* LEFT SECTION: Career Areas Bento Grid (lg:span-5) */}
      <div className="lg:col-span-5 h-full flex flex-col space-y-6">
        <div className="bg-white p-5 rounded-lg border border-slate-200">
          <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
            <Briefcase className="text-[#002f6c]" size={18} />
            <h3 className="text-base font-bold text-slate-900 m-0">
              Guia de Áreas de Carreira (Curitiba)
            </h3>
          </div>
          <p className="text-xs text-slate-500 font-light mt-1">
            Explore remunerações locais e quais faculdades oferecem as principais cadeiras de ensino técnico e superior.
          </p>

          {/* List of Careers */}
          <div className="space-y-3 mt-4" id="careers-list">
            {careerAreas.map((career) => {
              const CustomIcon = IconMap[career.iconName] || Compass;
              const isSelected = selectedCareer?.id === career.id;

              return (
                <div
                  key={career.id}
                  onClick={() => setSelectedCareer(isSelected ? null : career)}
                  className={`p-3 rounded-lg border transition duration-150 cursor-pointer ${
                    isSelected
                      ? "border-[#002f6c] bg-[#002f6c]/5 ring-1 ring-[#002f6c]"
                      : "border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <div className="p-1.5 bg-slate-100 text-[#002f6c] rounded">
                        <CustomIcon size={16} />
                      </div>
                      <h4 className="text-xs font-bold text-slate-800 m-0">
                        {career.name}
                      </h4>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {career.category}
                    </span>
                  </div>

                  {/* Expandable info block */}
                  {isSelected && (
                    <div className="mt-3 pt-3 border-t border-slate-200/50 text-xs space-y-3 animate-fade-in">
                      <p className="text-slate-600 font-light leading-relaxed">
                        {career.description}
                      </p>

                      <div className="grid grid-cols-2 gap-2 bg-white p-2.5 rounded border border-slate-100">
                        <div>
                          <span className="text-[9px] uppercase font-bold text-slate-400 block">
                            Média Salarial Local
                          </span>
                          <span className="text-xs font-bold text-[#002f6c] block">
                            {career.salariesCuritiba}
                          </span>
                        </div>
                        <div>
                          <span className="text-[9px] uppercase font-bold text-slate-400 block">
                            Onde Estudar (CTBA)
                          </span>
                          <span className="text-[11px] font-semibold text-slate-700 block">
                            {career.institutionsOffering.join(", ")}
                          </span>
                        </div>
                      </div>

                      {/* Required skills list */}
                      <div>
                        <span className="text-[9px] uppercase font-bold text-slate-400 block mb-1">
                          Habilidades Desejáveis
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {career.skills.map((skill, idx) => (
                            <span
                              key={idx}
                              className="text-[9px] bg-slate-150 text-slate-700 px-1.5 py-0.5 rounded border border-slate-200/40"
                            >
                              ✓ {skill}
                            </span>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          triggerCareerAssistantQuestion(career.name);
                        }}
                        className="w-full py-1.5 bg-[#002f6c] text-white rounded text-[10px] font-bold uppercase tracking-wider hover:bg-[#001d44] transition flex items-center justify-center space-x-1"
                      >
                        <span>Pedir Parecer IA sobre {career.name}</span>
                        <ArrowRight size={10} />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* RIGHT SECTION: Interactive Gemini virtual assistant (lg:span-7) */}
      <div className="lg:col-span-7 flex flex-col h-[580px] bg-white rounded-lg border border-slate-200 shadow-xs">
        {/* Assistant Header */}
        <div className="p-4 bg-[#002f6c] text-white flex items-center justify-between rounded-t-lg shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-amber-400 rounded text-slate-900 shadow-sm">
              <Sparkles size={16} />
            </div>
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wide text-white m-0">
                Assistente Virtual GuiaEstudantil
              </h3>
              <p className="text-[10px] text-slate-300 font-light mt-0.5 block">
                Inteligência Artificial para sanar dúvidas focada no ecossistema paranaense
              </p>
            </div>
          </div>
          <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-bold uppercase">
            Gemini Ativo
          </span>
        </div>

        {/* Messages Body */}
        <div className="flex-grow p-4 overflow-y-auto space-y-4 text-xs font-light" id="chat-messages-container">
          {messages.map((msg) => {
            const isAsst = msg.sender === "assistant";

            return (
              <div
                key={msg.id}
                className={`flex ${isAsst ? "justify-start" : "justify-end"} items-start gap-2.5`}
              >
                {isAsst && (
                  <div className="p-1 px-1.5 bg-amber-100 text-[#002f6c] font-bold rounded-full shrink-0 text-[10px]">
                    IA
                  </div>
                )}
                <div
                  className={`p-3 rounded-lg max-w-[85%] space-y-1.5 ${
                    isAsst
                      ? "bg-[#f8fafc] text-slate-800 border border-slate-200/60 leading-relaxed"
                      : "bg-[#0b4885] text-white shadow-sm"
                  }`}
                >
                  <p className="whitespace-pre-wrap font-sans break-words m-0">
                    {msg.text}
                  </p>
                  <span
                    className={`text-[9px] block text-right font-mono ${
                      isAsst ? "text-slate-400" : "text-blue-200"
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            );
          })}

          {isSending && (
            <div className="flex justify-start items-center space-x-2.5 text-slate-500 italic font-mono text-[10px]">
              <div className="flex space-x-1">
                <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-100"></span>
                <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-200"></span>
              </div>
              <span>Assistente está compilando parecer acadêmico...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggestion Chips Section */}
        <div className="px-4 py-2 border-t border-slate-100 bg-slate-50 shrink-0 select-none">
          <span className="text-[9px] font-bold uppercase text-slate-400 tracking-wider block mb-1.5">
            Dúvidas Frequentes de Estudantes
          </span>
          <div className="flex flex-wrap gap-1.5 max-h-[55px] overflow-y-auto">
            {suggestionChips.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSendText(chip)}
                disabled={isSending}
                className="text-[10px] text-slate-700 bg-white border border-slate-200 hover:border-[#002f6c] hover:bg-[#002f6c]/5 rounded-full px-2.5 py-1 text-left cursor-pointer transition duration-150 disabled:opacity-50"
              >
                {chip}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Input Footer */}
        <form onSubmit={handleFormSubmit} className="p-3 border-t border-slate-200 shrink-0 flex gap-2">
          <input
            type="text"
            id="chat-input-text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            disabled={isSending}
            placeholder="Pergunte sobre isenções, prazos da UFPR/UTFPR, cotas, etc..."
            className="flex-grow px-3 py-2 border border-slate-300 rounded text-xs focus:outline-none focus:border-[#002f6c]"
            required
          />
          <button
            type="submit"
            disabled={isSending || !inputValue.trim()}
            id="chat-submit-btn"
            className="px-3 bg-[#002f6c] hover:bg-[#001d44] text-white rounded transition flex items-center justify-center cursor-pointer disabled:opacity-50"
            title="Enviar mensagem"
          >
            <Send size={14} />
          </button>
        </form>
      </div>
    </div>
  );
}
